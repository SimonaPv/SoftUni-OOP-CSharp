﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.Shapes
{
    public interface IDrawable
    {
        void Draw();
    }
}
